from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib import messages
from .forms import UserRegistrationForm
from django.contrib.auth.models import User
from django.http import JsonResponse
from .forms import profile
from .models import form_model
import json

def home(request):
    return render(request, 'task_app/home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()

            messages.success(request, f'Your account has been created. You can log in now!')
            return redirect('login')
    else:
        form = UserRegistrationForm()

    context = {'form': form}
    return render(request, 'task_app/register.html', context)


def home_view(request):
    context = {}

    # create object of form
    form = profile(request.POST or None, request.FILES or None)

    # check if form data is valid
    if form.is_valid():
        # save the form data to model
       form.save()

    context['form'] = form

    return render(request, "task_app/home.html", context)


def jsondata(request):
    data = list(User.objects.values())
    #jsonString = json.dumps(data)
    f = open(r'C:\Users\EXOZENIOT1\django\task1\task\task_app\data.json', 'w')
    #s_data= dict(data)
    #f.close()
    #json_object = json.loads(s_data)
    #print(type(json_object))
    f.write(str(data))


    return JsonResponse(data, safe=False)

def jsondata1(request):
    data = list(form_model.objects.values())
    #jsonString = json.dumps(data)
    f = open(r'C:\Users\EXOZENIOT1\django\task1\task\task_app\profile.json', 'w')
    #s_data= dict(data)
    #f.close()
    #json_object = json.loads(s_data)
    #print(type(json_object))
    f.write(str(data))


    return JsonResponse(data, safe=False)