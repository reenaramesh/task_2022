from django.db import models



# declare a new model with a name "GeeksModel"
class form_model(models.Model):
    # fields of the model
    p_title = models.CharField(max_length=200)
    p_description = models.TextField()
    last_modified = models.DateTimeField(auto_now_add=True)
    password= models.CharField(max_length=200)

    # renames the instances of the model
    # with their title name
    def __str__(self):
        return self.p_title

