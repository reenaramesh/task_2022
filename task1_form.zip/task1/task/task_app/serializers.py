from rest_framework import serializers
#from .models import form_model_updated
from .forms import UserRegistrationForm

class form_modelSerializer(serializers.ModelSerializer):
    p_title = serializers.CharField(max_length=200)
    p_description = serializers.CharField(max_length=200)

    password = serializers.CharField(max_length=200)
    class Meta:
        model = form_model_updated
        fields   = ('__all__')