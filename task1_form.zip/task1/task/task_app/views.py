from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib import messages
from .forms import UserRegistrationForm
from django.contrib.auth.models import User
from django.http import JsonResponse
import json

def home(request):
    return render(request, 'task_app/home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()

            messages.success(request, f'Your account has been created. You can log in now!')
            return redirect('login')
    else:
        form = UserRegistrationForm()

    context = {'form': form}
    return render(request, 'task_app/register.html', context)


def jsondata(request):
    data = list(User.objects.values())
    #print(data)
    #data_str = ' '.join([str(i) for i in data])
    a = JsonResponse(data, safe=False)
    #jsonString = json.dumps(data)
    f = open(r'\Users\EXOZENIOT1\django\data.json', "w")
    f.write(str(data))
    #f.close()


    return a
    #f = open(r'\Users\EXOZENIOT1\django\data_json.json', "w")
    #print(data)
    #f.write(data_str)
    #f.close()

    #aList = [{"a": 54, "b": 87}, {"c": 81, "d": 63}, {"e": 17, "f": 39}]
