from django import forms

# import GeeksModel from models.py
from .models import form_model


# create a ModelForm
class form1(forms.ModelForm):
    # specify the name of model to use
    class Meta:
        model = form_model
        fields = "__all__"