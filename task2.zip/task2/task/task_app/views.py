from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import form_modelSerializer

from django.shortcuts import render
from .forms import form1


from django.http import JsonResponse
from .models import form_model


def home_view(request):
    context = {}

    # create object of form
    form = form1(request.POST or None, request.FILES or None)

    # check if form data is valid
    if form.is_valid():
        # save the form data to model
       form.save()

    context['form'] = form
    return render(request, "task_app/home.html", context)



def jsondata(request):
        data= list(form_model.objects.values())


        return JsonResponse(data, safe=False)

class form_modelViews(APIView):
    def post(self, request):
        serializer = form_modelSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)